<?php 
// No direct access
defined('_JEXEC') or die;
echo $hello."<br>";
 ?>